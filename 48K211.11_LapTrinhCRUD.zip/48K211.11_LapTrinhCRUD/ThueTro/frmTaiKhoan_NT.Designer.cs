﻿using System;

namespace ThueTro
{
    partial class frmTaiKhoan_NT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTaiKhoan_NT));
            this.txtMatKhau_NT = new System.Windows.Forms.TextBox();
            this.txtTenDN_NT = new System.Windows.Forms.TextBox();
            this.lbMatKhau_NT = new System.Windows.Forms.Label();
            this.lbTenDN_NT = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtMatKhau_NT
            // 
            this.txtMatKhau_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhau_NT.Location = new System.Drawing.Point(235, 120);
            this.txtMatKhau_NT.Name = "txtMatKhau_NT";
            this.txtMatKhau_NT.Size = new System.Drawing.Size(199, 27);
            this.txtMatKhau_NT.TabIndex = 2;
            // 
            // txtTenDN_NT
            // 
            this.txtTenDN_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDN_NT.Location = new System.Drawing.Point(235, 52);
            this.txtTenDN_NT.Name = "txtTenDN_NT";
            this.txtTenDN_NT.Size = new System.Drawing.Size(199, 27);
            this.txtTenDN_NT.TabIndex = 0;
            // 
            // lbMatKhau_NT
            // 
            this.lbMatKhau_NT.AutoSize = true;
            this.lbMatKhau_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbMatKhau_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMatKhau_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbMatKhau_NT.Location = new System.Drawing.Point(49, 120);
            this.lbMatKhau_NT.Name = "lbMatKhau_NT";
            this.lbMatKhau_NT.Size = new System.Drawing.Size(91, 20);
            this.lbMatKhau_NT.TabIndex = 13;
            this.lbMatKhau_NT.Text = "Mật khẩu:";
            // 
            // lbTenDN_NT
            // 
            this.lbTenDN_NT.AutoSize = true;
            this.lbTenDN_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbTenDN_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenDN_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTenDN_NT.Location = new System.Drawing.Point(49, 55);
            this.lbTenDN_NT.Name = "lbTenDN_NT";
            this.lbTenDN_NT.Size = new System.Drawing.Size(138, 20);
            this.lbTenDN_NT.TabIndex = 12;
            this.lbTenDN_NT.Text = "Tên đăng nhập:";
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSua.Location = new System.Drawing.Point(345, 206);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 41);
            this.btnSua.TabIndex = 4;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnXoa.Location = new System.Drawing.Point(546, 204);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 43);
            this.btnXoa.TabIndex = 5;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLuu.Location = new System.Drawing.Point(159, 205);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 41);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 277);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(733, 196);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // frmTaiKhoan_NT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.txtMatKhau_NT);
            this.Controls.Add(this.txtTenDN_NT);
            this.Controls.Add(this.lbMatKhau_NT);
            this.Controls.Add(this.lbTenDN_NT);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmTaiKhoan_NT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tài khoản người thuê";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTaiKhoan_NT_FormClosing);
            this.Load += new System.EventHandler(this.frmTaiKhoan_NT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatKhau_NT;
        private System.Windows.Forms.TextBox txtTenDN_NT;
        private System.Windows.Forms.Label lbMatKhau_NT;
        private System.Windows.Forms.Label lbTenDN_NT;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EventHandler txtMatKhau_CT_TextChanged;
        private EventHandler txtTenDN_CT_TextChanged;
    }
}
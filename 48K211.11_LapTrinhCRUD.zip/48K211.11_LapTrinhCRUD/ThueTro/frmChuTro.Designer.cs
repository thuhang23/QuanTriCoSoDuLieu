﻿using System;

namespace ThueTro
{
    partial class frmChuTro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChuTro));
            this.lbCCCD_CT = new System.Windows.Forms.Label();
            this.txtCCCD_CT = new System.Windows.Forms.TextBox();
            this.lbTen_CT = new System.Windows.Forms.Label();
            this.txtTen_CT = new System.Windows.Forms.TextBox();
            this.lbSDT_CT = new System.Windows.Forms.Label();
            this.txtSDT_CT = new System.Windows.Forms.TextBox();
            this.lbDiaChi_CT = new System.Windows.Forms.Label();
            this.txtDiaChi_CT = new System.Windows.Forms.TextBox();
            this.lbTenDN_CT = new System.Windows.Forms.Label();
            this.lbMatKhau_CT = new System.Windows.Forms.Label();
            this.txtTenDN_CT = new System.Windows.Forms.TextBox();
            this.txtMatKhau_CT = new System.Windows.Forms.TextBox();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnSua = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbCCCD_CT
            // 
            this.lbCCCD_CT.AutoSize = true;
            this.lbCCCD_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbCCCD_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCCCD_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbCCCD_CT.Location = new System.Drawing.Point(47, 56);
            this.lbCCCD_CT.Name = "lbCCCD_CT";
            this.lbCCCD_CT.Size = new System.Drawing.Size(68, 20);
            this.lbCCCD_CT.TabIndex = 0;
            this.lbCCCD_CT.Text = "CCCD:";
            // 
            // txtCCCD_CT
            // 
            this.txtCCCD_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCCCD_CT.Location = new System.Drawing.Point(194, 49);
            this.txtCCCD_CT.Name = "txtCCCD_CT";
            this.txtCCCD_CT.Size = new System.Drawing.Size(199, 27);
            this.txtCCCD_CT.TabIndex = 0;
            // 
            // lbTen_CT
            // 
            this.lbTen_CT.AutoSize = true;
            this.lbTen_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbTen_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTen_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTen_CT.Location = new System.Drawing.Point(47, 121);
            this.lbTen_CT.Name = "lbTen_CT";
            this.lbTen_CT.Size = new System.Drawing.Size(96, 20);
            this.lbTen_CT.TabIndex = 2;
            this.lbTen_CT.Text = "Họ và tên:";
            // 
            // txtTen_CT
            // 
            this.txtTen_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTen_CT.Location = new System.Drawing.Point(194, 118);
            this.txtTen_CT.Name = "txtTen_CT";
            this.txtTen_CT.Size = new System.Drawing.Size(199, 27);
            this.txtTen_CT.TabIndex = 1;
            // 
            // lbSDT_CT
            // 
            this.lbSDT_CT.AutoSize = true;
            this.lbSDT_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbSDT_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSDT_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbSDT_CT.Location = new System.Drawing.Point(47, 185);
            this.lbSDT_CT.Name = "lbSDT_CT";
            this.lbSDT_CT.Size = new System.Drawing.Size(125, 20);
            this.lbSDT_CT.TabIndex = 4;
            this.lbSDT_CT.Text = "Số điện thoại:";
            // 
            // txtSDT_CT
            // 
            this.txtSDT_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_CT.Location = new System.Drawing.Point(194, 182);
            this.txtSDT_CT.Name = "txtSDT_CT";
            this.txtSDT_CT.Size = new System.Drawing.Size(199, 27);
            this.txtSDT_CT.TabIndex = 2;
            // 
            // lbDiaChi_CT
            // 
            this.lbDiaChi_CT.AutoSize = true;
            this.lbDiaChi_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbDiaChi_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiaChi_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbDiaChi_CT.Location = new System.Drawing.Point(47, 245);
            this.lbDiaChi_CT.Name = "lbDiaChi_CT";
            this.lbDiaChi_CT.Size = new System.Drawing.Size(74, 20);
            this.lbDiaChi_CT.TabIndex = 6;
            this.lbDiaChi_CT.Text = "Địa chỉ:";
            // 
            // txtDiaChi_CT
            // 
            this.txtDiaChi_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi_CT.Location = new System.Drawing.Point(194, 242);
            this.txtDiaChi_CT.Name = "txtDiaChi_CT";
            this.txtDiaChi_CT.Size = new System.Drawing.Size(383, 27);
            this.txtDiaChi_CT.TabIndex = 3;
            // 
            // lbTenDN_CT
            // 
            this.lbTenDN_CT.AutoSize = true;
            this.lbTenDN_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbTenDN_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenDN_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTenDN_CT.Location = new System.Drawing.Point(439, 56);
            this.lbTenDN_CT.Name = "lbTenDN_CT";
            this.lbTenDN_CT.Size = new System.Drawing.Size(138, 20);
            this.lbTenDN_CT.TabIndex = 8;
            this.lbTenDN_CT.Text = "Tên đăng nhập:";
            // 
            // lbMatKhau_CT
            // 
            this.lbMatKhau_CT.AutoSize = true;
            this.lbMatKhau_CT.BackColor = System.Drawing.Color.Transparent;
            this.lbMatKhau_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMatKhau_CT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbMatKhau_CT.Location = new System.Drawing.Point(439, 121);
            this.lbMatKhau_CT.Name = "lbMatKhau_CT";
            this.lbMatKhau_CT.Size = new System.Drawing.Size(91, 20);
            this.lbMatKhau_CT.TabIndex = 9;
            this.lbMatKhau_CT.Text = "Mật khẩu:";
            // 
            // txtTenDN_CT
            // 
            this.txtTenDN_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDN_CT.Location = new System.Drawing.Point(596, 49);
            this.txtTenDN_CT.Name = "txtTenDN_CT";
            this.txtTenDN_CT.Size = new System.Drawing.Size(199, 27);
            this.txtTenDN_CT.TabIndex = 4;
            // 
            // txtMatKhau_CT
            // 
            this.txtMatKhau_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhau_CT.Location = new System.Drawing.Point(596, 121);
            this.txtMatKhau_CT.Name = "txtMatKhau_CT";
            this.txtMatKhau_CT.Size = new System.Drawing.Size(199, 27);
            this.txtMatKhau_CT.TabIndex = 5;
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLuu.Location = new System.Drawing.Point(176, 295);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 41);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnXoa.Location = new System.Drawing.Point(583, 294);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 43);
            this.btnXoa.TabIndex = 8;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Location = new System.Drawing.Point(34, 353);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(818, 218);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSua.Location = new System.Drawing.Point(385, 294);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 41);
            this.btnSua.TabIndex = 7;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // frmChuTro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(888, 588);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.txtMatKhau_CT);
            this.Controls.Add(this.txtTenDN_CT);
            this.Controls.Add(this.lbMatKhau_CT);
            this.Controls.Add(this.lbTenDN_CT);
            this.Controls.Add(this.txtDiaChi_CT);
            this.Controls.Add(this.lbDiaChi_CT);
            this.Controls.Add(this.txtSDT_CT);
            this.Controls.Add(this.lbSDT_CT);
            this.Controls.Add(this.txtTen_CT);
            this.Controls.Add(this.lbTen_CT);
            this.Controls.Add(this.txtCCCD_CT);
            this.Controls.Add(this.lbCCCD_CT);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmChuTro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chủ trọ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmChuTro_FormClosing);
            this.Load += new System.EventHandler(this.frmChuTro_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbCCCD_CT;
        private System.Windows.Forms.TextBox txtCCCD_CT;
        private System.Windows.Forms.Label lbTen_CT;
        private System.Windows.Forms.TextBox txtTen_CT;
        private System.Windows.Forms.Label lbSDT_CT;
        private System.Windows.Forms.TextBox txtSDT_CT;
        private System.Windows.Forms.Label lbDiaChi_CT;
        private System.Windows.Forms.TextBox txtDiaChi_CT;
        private System.Windows.Forms.Label lbTenDN_CT;
        private System.Windows.Forms.Label lbMatKhau_CT;
        private System.Windows.Forms.TextBox txtTenDN_CT;
        private System.Windows.Forms.TextBox txtMatKhau_CT;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EventHandler label1_Click;
        private EventHandler label1_Click_1;
        private EventHandler textBox2_TextChanged;
        private EventHandler label2_Click;
        private EventHandler textBox1_TextChanged;
        private EventHandler button2_Click;
        private EventHandler frmChuTro_Load;
        private System.Windows.Forms.Button btnSua;
    }
}
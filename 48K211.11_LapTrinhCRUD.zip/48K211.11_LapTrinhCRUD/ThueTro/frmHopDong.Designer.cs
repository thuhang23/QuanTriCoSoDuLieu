﻿using System;

namespace ThueTro
{
    partial class frmHopDong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHopDong));
            this.txtSoPhong = new System.Windows.Forms.TextBox();
            this.lbSoPhong = new System.Windows.Forms.Label();
            this.txtCCCD_NT = new System.Windows.Forms.TextBox();
            this.lbCCCD_NT = new System.Windows.Forms.Label();
            this.txtMaHopDong = new System.Windows.Forms.TextBox();
            this.lbMaHopDong = new System.Windows.Forms.Label();
            this.lbNgayHetHan = new System.Windows.Forms.Label();
            this.lbNgayThueTro = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSoPhong
            // 
            this.txtSoPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPhong.Location = new System.Drawing.Point(205, 169);
            this.txtSoPhong.Name = "txtSoPhong";
            this.txtSoPhong.Size = new System.Drawing.Size(199, 27);
            this.txtSoPhong.TabIndex = 2;
            // 
            // lbSoPhong
            // 
            this.lbSoPhong.AutoSize = true;
            this.lbSoPhong.BackColor = System.Drawing.Color.Transparent;
            this.lbSoPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoPhong.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbSoPhong.Location = new System.Drawing.Point(25, 172);
            this.lbSoPhong.Name = "lbSoPhong";
            this.lbSoPhong.Size = new System.Drawing.Size(93, 20);
            this.lbSoPhong.TabIndex = 10;
            this.lbSoPhong.Text = "Số phòng:";
            // 
            // txtCCCD_NT
            // 
            this.txtCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCCCD_NT.Location = new System.Drawing.Point(205, 105);
            this.txtCCCD_NT.Name = "txtCCCD_NT";
            this.txtCCCD_NT.Size = new System.Drawing.Size(199, 27);
            this.txtCCCD_NT.TabIndex = 1;
            // 
            // lbCCCD_NT
            // 
            this.lbCCCD_NT.AutoSize = true;
            this.lbCCCD_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCCCD_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbCCCD_NT.Location = new System.Drawing.Point(25, 108);
            this.lbCCCD_NT.Name = "lbCCCD_NT";
            this.lbCCCD_NT.Size = new System.Drawing.Size(161, 20);
            this.lbCCCD_NT.TabIndex = 9;
            this.lbCCCD_NT.Text = "CCCD người thuê:";
            this.lbCCCD_NT.Click += new System.EventHandler(this.lbCCCD_NT_Click);
            // 
            // txtMaHopDong
            // 
            this.txtMaHopDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHopDong.Location = new System.Drawing.Point(205, 36);
            this.txtMaHopDong.Name = "txtMaHopDong";
            this.txtMaHopDong.Size = new System.Drawing.Size(199, 27);
            this.txtMaHopDong.TabIndex = 0;
            // 
            // lbMaHopDong
            // 
            this.lbMaHopDong.AutoSize = true;
            this.lbMaHopDong.BackColor = System.Drawing.Color.Transparent;
            this.lbMaHopDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaHopDong.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbMaHopDong.Location = new System.Drawing.Point(25, 43);
            this.lbMaHopDong.Name = "lbMaHopDong";
            this.lbMaHopDong.Size = new System.Drawing.Size(122, 20);
            this.lbMaHopDong.TabIndex = 6;
            this.lbMaHopDong.Text = "Mã hợp đồng:";
            // 
            // lbNgayHetHan
            // 
            this.lbNgayHetHan.AutoSize = true;
            this.lbNgayHetHan.BackColor = System.Drawing.Color.Transparent;
            this.lbNgayHetHan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayHetHan.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbNgayHetHan.Location = new System.Drawing.Point(434, 108);
            this.lbNgayHetHan.Name = "lbNgayHetHan";
            this.lbNgayHetHan.Size = new System.Drawing.Size(125, 20);
            this.lbNgayHetHan.TabIndex = 12;
            this.lbNgayHetHan.Text = "Ngày hết hạn:";
            // 
            // lbNgayThueTro
            // 
            this.lbNgayThueTro.AutoSize = true;
            this.lbNgayThueTro.BackColor = System.Drawing.Color.Transparent;
            this.lbNgayThueTro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayThueTro.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbNgayThueTro.Location = new System.Drawing.Point(434, 43);
            this.lbNgayThueTro.Name = "lbNgayThueTro";
            this.lbNgayThueTro.Size = new System.Drawing.Size(128, 20);
            this.lbNgayThueTro.TabIndex = 11;
            this.lbNgayThueTro.Text = "Ngày thuê trọ:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(586, 41);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(195, 22);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(586, 106);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(195, 22);
            this.dateTimePicker2.TabIndex = 4;
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSua.Location = new System.Drawing.Point(368, 234);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 41);
            this.btnSua.TabIndex = 6;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.BtnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnXoa.Location = new System.Drawing.Point(566, 234);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 43);
            this.btnXoa.TabIndex = 7;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLuu.Location = new System.Drawing.Point(159, 235);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 41);
            this.btnLuu.TabIndex = 5;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(42, 300);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(770, 205);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // frmHopDong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(849, 529);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbNgayHetHan);
            this.Controls.Add(this.lbNgayThueTro);
            this.Controls.Add(this.txtSoPhong);
            this.Controls.Add(this.lbSoPhong);
            this.Controls.Add(this.txtCCCD_NT);
            this.Controls.Add(this.lbCCCD_NT);
            this.Controls.Add(this.txtMaHopDong);
            this.Controls.Add(this.lbMaHopDong);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmHopDong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hợp đồng";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHopDong_FormClosing);
            this.Load += new System.EventHandler(this.frmHopDong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void lbCCCD_NT_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.TextBox txtSoPhong;
        private System.Windows.Forms.Label lbSoPhong;
        private System.Windows.Forms.TextBox txtCCCD_NT;
        private System.Windows.Forms.Label lbCCCD_NT;
        private System.Windows.Forms.TextBox txtMaHopDong;
        private System.Windows.Forms.Label lbMaHopDong;
        private System.Windows.Forms.Label lbNgayHetHan;
        private System.Windows.Forms.Label lbNgayThueTro;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private EventHandler txtCCCD_CT_TextChanged;
        private EventHandler lbCCCD_CT_Click;
        private EventHandler lbTenDN_CT_Click;
        private EventHandler dateTimePicker1_ValueChanged;
        private EventHandler dateTimePicker2_ValueChanged;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EventHandler lbMaHopDong_Click;
        private EventHandler btnSua_Click;
    }
}
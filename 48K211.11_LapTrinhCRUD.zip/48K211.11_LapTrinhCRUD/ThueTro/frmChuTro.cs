﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmChuTro : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmChuTro()
        {
            InitializeComponent();
        }

        private void frmChuTro_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void frmChuTro_Load_1(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from CHUTRO";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "CHUTRO");

            dataGridView1.DataSource = ds.Tables["CHUTRO"];

            con.Close(); //bước 3

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sCCCD_CT = txtCCCD_CT.Text.Trim();
            string sTen_CT = txtTen_CT.Text.Trim();
            string sSDT_CT = txtSDT_CT.Text.Trim();
            string sDiaChi_CT = txtDiaChi_CT.Text.Trim();
            string sTenDN_CT = txtTenDN_CT.Text.Trim();
            string sMatKhau_CT = txtMatKhau_CT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sCCCD_CT) || string.IsNullOrEmpty(sTen_CT) ||
                string.IsNullOrEmpty(sSDT_CT) || string.IsNullOrEmpty(sDiaChi_CT) ||
                string.IsNullOrEmpty(sTenDN_CT) || string.IsNullOrEmpty(sMatKhau_CT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sCCCD_CT.Length != 12)
            {
                MessageBox.Show("CCCD phải đúng 12 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            if (sSDT_CT.Length != 10)
            {
                MessageBox.Show("Số điện thoại phải đúng 10 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra trùng lặp
            // Kiểm tra CCCD_CT
            string checkCCCDQuery = "SELECT COUNT(*) FROM CHUTRO WHERE CCCD_CT = @CCCD_CT";
            SqlCommand checkCCCDCmd = new SqlCommand(checkCCCDQuery, con);
            checkCCCDCmd.Parameters.AddWithValue("@CCCD_CT", sCCCD_CT);

            int cccdExists = (int)checkCCCDCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (cccdExists > 0)
            {
                MessageBox.Show("CCCD đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra TenDN_CT
            string checkTenDNQuery = "SELECT COUNT(*) FROM CHUTRO WHERE TenDN_CT = @TenDN_CT";
            SqlCommand checkTenDNCmd = new SqlCommand(checkTenDNQuery, con);
            checkTenDNCmd.Parameters.AddWithValue("@TenDN_CT", sTenDN_CT);

            int tenDNExists = (int)checkTenDNCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (tenDNExists > 0)
            {
                MessageBox.Show("Tài khoản đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "insert into CHUTRO values (@CCCD_CT, @Ten_CT, @SDT_CT, @DiaChi_CT, @TenDN_CT, @MatKhau_CT)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_CT", sCCCD_CT);
            cmd.Parameters.AddWithValue("@Ten_CT", sTen_CT);
            cmd.Parameters.AddWithValue("@SDT_CT", sSDT_CT);
            cmd.Parameters.AddWithValue("@DiaChi_CT", sDiaChi_CT);
            cmd.Parameters.AddWithValue("@TenDN_CT", sTenDN_CT);
            cmd.Parameters.AddWithValue("@MatKhau_CT", sMatKhau_CT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!", "Thông báo");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình thêm mới!", "Thông báo");
            }

            con.Close(); //Bước 3
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCCCD_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["CCCD_CT"].Value.ToString();
            txtTen_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["Ten_CT"].Value.ToString();
            txtSDT_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["SDT_CT"].Value.ToString();
            txtDiaChi_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["DiaChi_CT"].Value.ToString();
            txtTenDN_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["TenDN_CT"].Value.ToString();
            txtMatKhau_CT.Text = dataGridView1.Rows[e.RowIndex].Cells["MatKhau_CT"].Value.ToString();

            txtCCCD_CT.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sCCCD_CT = txtCCCD_CT.Text.Trim();
            string sTen_CT = txtTen_CT.Text.Trim();
            string sSDT_CT = txtSDT_CT.Text.Trim();
            string sDiaChi_CT = txtDiaChi_CT.Text.Trim();
            string sTenDN_CT = txtTenDN_CT.Text.Trim();
            string sMatKhau_CT = txtMatKhau_CT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sTen_CT) ||
                string.IsNullOrEmpty(sSDT_CT) || string.IsNullOrEmpty(sDiaChi_CT) ||
                string.IsNullOrEmpty(sTenDN_CT) || string.IsNullOrEmpty(sMatKhau_CT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sSDT_CT.Length != 10)
            {
                MessageBox.Show("Số điện thoại phải đúng 10 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra tên đăng nhập có bị trùng trong cơ sở dữ liệu hay không
            string checkQuery = "SELECT COUNT(*) FROM CHUTRO WHERE TenDN_CT = @TenDN_CT AND CCCD_CT != @CCCD_CT";
            SqlCommand checkCmd = new SqlCommand(checkQuery, con);
            checkCmd.Parameters.AddWithValue("@TenDN_CT", sTenDN_CT);
            checkCmd.Parameters.AddWithValue("@CCCD_CT", sCCCD_CT);

            int count = (int)checkCmd.ExecuteScalar();
            if (count > 0)
            {
                MessageBox.Show("Tên đăng nhập đã bị trùng! Vui lòng chọn tên khác.", "Thông báo");
                con.Close();
                return; // Dừng lại nếu tên đăng nhập bị trùng
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "update CHUTRO set Ten_CT = @Ten_CT, SDT_CT = @SDT_CT, " +
                    "DiaChi_CT = @DiaChi_CT, TenDN_CT = @TenDN_CT, MatKhau_CT = @MatKhau_CT " +
                    "WHERE CCCD_CT = @CCCD_CT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_CT", sCCCD_CT);
            cmd.Parameters.AddWithValue("@Ten_CT", sTen_CT);
            cmd.Parameters.AddWithValue("@SDT_CT", sSDT_CT);
            cmd.Parameters.AddWithValue("@DiaChi_CT", sDiaChi_CT);
            cmd.Parameters.AddWithValue("@TenDN_CT", sTenDN_CT);
            cmd.Parameters.AddWithValue("@MatKhau_CT", sMatKhau_CT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sCCCD_CT=txtCCCD_CT.Text;

            string sQuery = "delete CHUTRO where CCCD_CT = @CCCD_CT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_CT", sCCCD_CT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}

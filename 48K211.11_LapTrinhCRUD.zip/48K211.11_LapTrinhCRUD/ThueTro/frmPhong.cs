﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmPhong : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmPhong()
        {
            InitializeComponent();
        }

        private void frmPhong_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void frmPhong_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from PHONG";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "PHONG");

            dataGridView1.DataSource = ds.Tables["PHONG"];

            con.Close(); //bước 3
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sSoPhong = txtSoPhong.Text.Trim();
            string sLoaiPhong = txtLoaiPhong.Text.Trim();
            string sGiaPhong = txtGiaPhong.Text.Trim();
            string sDienTichPhong = txtDienTichPhong.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sSoPhong) || string.IsNullOrEmpty(sLoaiPhong) ||
                string.IsNullOrEmpty(sGiaPhong) || string.IsNullOrEmpty(sDienTichPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sSoPhong.Length != 3)
            {
                MessageBox.Show("Số phòng phải đúng 3 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra giá phòng không được nhỏ hơn 0
            if (!decimal.TryParse(sGiaPhong, out decimal giaPhong) || giaPhong <= 0)
            {
                MessageBox.Show("Giá phòng không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra diện tích phòng không được nhỏ hơn 0
            if (!decimal.TryParse(sDienTichPhong, out decimal dienTich) || dienTich <= 0)
            {
                MessageBox.Show("Diện tích phòng không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra trùng lặp
            // Kiểm tra SoPhong 
            string checkSoPhongQuery = "SELECT COUNT(*) FROM PHONG WHERE SoPhong = @SoPhong";
            SqlCommand checkSoPhongCmd = new SqlCommand(checkSoPhongQuery, con);
            checkSoPhongCmd.Parameters.AddWithValue("@SoPhong", sSoPhong);

            int sophongExists = (int)checkSoPhongCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (sophongExists > 0)
            {
                MessageBox.Show("Số phòng đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "insert into PHONG values (@SoPhong, @LoaiPhong, @GiaPhong, @DienTichPhong)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@SoPhong", sSoPhong);
            cmd.Parameters.AddWithValue("@LoaiPhong", sLoaiPhong);
            cmd.Parameters.AddWithValue("@GiaPhong", sGiaPhong);
            cmd.Parameters.AddWithValue("@DienTichPhong", sDienTichPhong);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình thêm mới!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtSoPhong.Text = dataGridView1.Rows[e.RowIndex].Cells["SoPhong"].Value.ToString();
            txtLoaiPhong.Text = dataGridView1.Rows[e.RowIndex].Cells["LoaiPhong"].Value.ToString();
            txtGiaPhong.Text = dataGridView1.Rows[e.RowIndex].Cells["GiaPhong"].Value.ToString();
            txtDienTichPhong.Text = dataGridView1.Rows[e.RowIndex].Cells["DienTichPhong"].Value.ToString();

            txtSoPhong.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sSoPhong = txtSoPhong.Text.Trim();
            string sLoaiPhong = txtLoaiPhong.Text.Trim();
            string sGiaPhong = txtGiaPhong.Text.Trim();
            string sDienTichPhong = txtDienTichPhong.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sLoaiPhong) ||
                string.IsNullOrEmpty(sGiaPhong) || string.IsNullOrEmpty(sDienTichPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra giá phòng không được nhỏ hơn 0
            if (!decimal.TryParse(sGiaPhong, out decimal giaPhong) || giaPhong <= 0)
            {
                MessageBox.Show("Giá phòng không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra diện tích phòng không được nhỏ hơn 0
            if (!decimal.TryParse(sDienTichPhong, out decimal dienTich) || dienTich <= 0)
            {
                MessageBox.Show("Diện tích phòng không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            //Thực hiện cập nhật
            string sQuery = "update PHONG set LoaiPhong = @LoaiPhong," +
                "GiaPhong = @GiaPhong, DienTichPhong = @DienTichPhong where SoPhong = @SoPhong";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@SoPhong", sSoPhong);
            cmd.Parameters.AddWithValue("@LoaiPhong", sLoaiPhong);
            cmd.Parameters.AddWithValue("@GiaPhong", sGiaPhong);
            cmd.Parameters.AddWithValue("@DienTichPhong", sDienTichPhong);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sSoPhong = txtSoPhong.Text;

            string sQuery = "delete PHONG where SoPhong = @SoPhong";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@SoPhong", sSoPhong);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}

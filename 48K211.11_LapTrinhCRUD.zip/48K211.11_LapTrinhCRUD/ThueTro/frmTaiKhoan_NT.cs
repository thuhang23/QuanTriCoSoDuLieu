﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmTaiKhoan_NT : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmTaiKhoan_NT()
        {
            InitializeComponent();
        }

        private void frmTaiKhoan_NT_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from TAIKHOAN_NT";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "TAIKHOAN_NT");

            dataGridView1.DataSource = ds.Tables["TAIKHOAN_NT"];

            con.Close(); //bước 3
        }

        private void frmTaiKhoan_NT_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sTenDN_NT = txtTenDN_NT.Text.Trim();
            string sMatKhau_NT = txtMatKhau_NT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sTenDN_NT) || string.IsNullOrEmpty(sMatKhau_NT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra TenDN_NT
            string checkTenDNQuery = "SELECT COUNT(*) FROM TAIKHOAN_NT WHERE TenDN_NT = @TenDN_NT";
            SqlCommand checkTenDNCmd = new SqlCommand(checkTenDNQuery, con);
            checkTenDNCmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            int tenDNExists = (int)checkTenDNCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (tenDNExists > 0)
            {
                MessageBox.Show("Tài khoản đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "insert into TAIKHOAN_NT values (@TenDN_NT, @MatKhau_NT)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);
            cmd.Parameters.AddWithValue("@MatKhau_NT", sMatKhau_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình thêm mới!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtTenDN_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["TenDN_NT"].Value.ToString();
            txtMatKhau_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["MatKhau_NT"].Value.ToString();

            txtTenDN_NT.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sTenDN_NT = txtTenDN_NT.Text.Trim();
            string sMatKhau_NT = txtMatKhau_NT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sMatKhau_NT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            string sQuery = "update TAIKHOAN_NT set MatKhau_NT = @MatKhau_NT where TenDN_NT = @TenDN_NT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);
            cmd.Parameters.AddWithValue("@MatKhau_NT", sMatKhau_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sTenDN_NT = txtTenDN_NT.Text;

            string sQuery = "delete TAIKHOAN_NT where TenDN_NT = @TenDN_NT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3

        }

    }
}

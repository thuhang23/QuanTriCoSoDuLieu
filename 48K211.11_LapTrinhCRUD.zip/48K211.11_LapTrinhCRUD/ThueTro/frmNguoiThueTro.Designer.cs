﻿using System;

namespace ThueTro
{
    partial class frmNguoiThueTro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNguoiThueTro));
            this.txtCCCD_NT = new System.Windows.Forms.TextBox();
            this.lbCCCD_NT = new System.Windows.Forms.Label();
            this.txtDiaChi_NT = new System.Windows.Forms.TextBox();
            this.lbDiaChi_NT = new System.Windows.Forms.Label();
            this.txtSDT_NT = new System.Windows.Forms.TextBox();
            this.lbSDT_NT = new System.Windows.Forms.Label();
            this.txtTen_NT = new System.Windows.Forms.TextBox();
            this.lbTen_NT = new System.Windows.Forms.Label();
            this.txtTenDN_NT = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lbTenDN_NT = new System.Windows.Forms.Label();
            this.lbEmail_NT = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCCCD_NT
            // 
            this.txtCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCCCD_NT.Location = new System.Drawing.Point(192, 55);
            this.txtCCCD_NT.Name = "txtCCCD_NT";
            this.txtCCCD_NT.Size = new System.Drawing.Size(199, 27);
            this.txtCCCD_NT.TabIndex = 0;
            // 
            // lbCCCD_NT
            // 
            this.lbCCCD_NT.AutoSize = true;
            this.lbCCCD_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCCCD_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbCCCD_NT.Location = new System.Drawing.Point(45, 62);
            this.lbCCCD_NT.Name = "lbCCCD_NT";
            this.lbCCCD_NT.Size = new System.Drawing.Size(68, 20);
            this.lbCCCD_NT.TabIndex = 2;
            this.lbCCCD_NT.Text = "CCCD:";
            // 
            // txtDiaChi_NT
            // 
            this.txtDiaChi_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi_NT.Location = new System.Drawing.Point(192, 244);
            this.txtDiaChi_NT.Name = "txtDiaChi_NT";
            this.txtDiaChi_NT.Size = new System.Drawing.Size(383, 27);
            this.txtDiaChi_NT.TabIndex = 3;
            // 
            // lbDiaChi_NT
            // 
            this.lbDiaChi_NT.AutoSize = true;
            this.lbDiaChi_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbDiaChi_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDiaChi_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbDiaChi_NT.Location = new System.Drawing.Point(45, 247);
            this.lbDiaChi_NT.Name = "lbDiaChi_NT";
            this.lbDiaChi_NT.Size = new System.Drawing.Size(74, 20);
            this.lbDiaChi_NT.TabIndex = 12;
            this.lbDiaChi_NT.Text = "Địa chỉ:";
            // 
            // txtSDT_NT
            // 
            this.txtSDT_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_NT.Location = new System.Drawing.Point(192, 184);
            this.txtSDT_NT.Name = "txtSDT_NT";
            this.txtSDT_NT.Size = new System.Drawing.Size(199, 27);
            this.txtSDT_NT.TabIndex = 2;
            // 
            // lbSDT_NT
            // 
            this.lbSDT_NT.AutoSize = true;
            this.lbSDT_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbSDT_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSDT_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbSDT_NT.Location = new System.Drawing.Point(45, 187);
            this.lbSDT_NT.Name = "lbSDT_NT";
            this.lbSDT_NT.Size = new System.Drawing.Size(125, 20);
            this.lbSDT_NT.TabIndex = 11;
            this.lbSDT_NT.Text = "Số điện thoại:";
            // 
            // txtTen_NT
            // 
            this.txtTen_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTen_NT.Location = new System.Drawing.Point(192, 120);
            this.txtTen_NT.Name = "txtTen_NT";
            this.txtTen_NT.Size = new System.Drawing.Size(199, 27);
            this.txtTen_NT.TabIndex = 1;
            // 
            // lbTen_NT
            // 
            this.lbTen_NT.AutoSize = true;
            this.lbTen_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbTen_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTen_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTen_NT.Location = new System.Drawing.Point(45, 123);
            this.lbTen_NT.Name = "lbTen_NT";
            this.lbTen_NT.Size = new System.Drawing.Size(96, 20);
            this.lbTen_NT.TabIndex = 9;
            this.lbTen_NT.Text = "Họ và tên:";
            // 
            // txtTenDN_NT
            // 
            this.txtTenDN_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDN_NT.Location = new System.Drawing.Point(618, 127);
            this.txtTenDN_NT.Name = "txtTenDN_NT";
            this.txtTenDN_NT.Size = new System.Drawing.Size(199, 27);
            this.txtTenDN_NT.TabIndex = 5;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(618, 55);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(199, 27);
            this.txtEmail.TabIndex = 4;
            // 
            // lbTenDN_NT
            // 
            this.lbTenDN_NT.AutoSize = true;
            this.lbTenDN_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbTenDN_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenDN_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTenDN_NT.Location = new System.Drawing.Point(461, 127);
            this.lbTenDN_NT.Name = "lbTenDN_NT";
            this.lbTenDN_NT.Size = new System.Drawing.Size(138, 20);
            this.lbTenDN_NT.TabIndex = 16;
            this.lbTenDN_NT.Text = "Tên đăng nhập:";
            // 
            // lbEmail_NT
            // 
            this.lbEmail_NT.AutoSize = true;
            this.lbEmail_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbEmail_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmail_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbEmail_NT.Location = new System.Drawing.Point(461, 62);
            this.lbEmail_NT.Name = "lbEmail_NT";
            this.lbEmail_NT.Size = new System.Drawing.Size(62, 20);
            this.lbEmail_NT.TabIndex = 15;
            this.lbEmail_NT.Text = "Email:";
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSua.Location = new System.Drawing.Point(412, 298);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 41);
            this.btnSua.TabIndex = 7;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnXoa.Location = new System.Drawing.Point(610, 298);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 43);
            this.btnXoa.TabIndex = 8;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLuu.Location = new System.Drawing.Point(203, 299);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 41);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.dataGridView1.GridColor = System.Drawing.Color.LightSkyBlue;
            this.dataGridView1.Location = new System.Drawing.Point(49, 347);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(809, 207);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // frmNguoiThueTro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(900, 566);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.txtTenDN_NT);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lbTenDN_NT);
            this.Controls.Add(this.lbEmail_NT);
            this.Controls.Add(this.txtDiaChi_NT);
            this.Controls.Add(this.lbDiaChi_NT);
            this.Controls.Add(this.txtSDT_NT);
            this.Controls.Add(this.lbSDT_NT);
            this.Controls.Add(this.txtTen_NT);
            this.Controls.Add(this.lbTen_NT);
            this.Controls.Add(this.txtCCCD_NT);
            this.Controls.Add(this.lbCCCD_NT);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmNguoiThueTro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Người thuê trọ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmNguoiThueTro_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCCCD_NT;
        private System.Windows.Forms.Label lbCCCD_NT;
        private System.Windows.Forms.TextBox txtDiaChi_NT;
        private System.Windows.Forms.Label lbDiaChi_NT;
        private System.Windows.Forms.TextBox txtSDT_NT;
        private System.Windows.Forms.Label lbSDT_NT;
        private System.Windows.Forms.TextBox txtTen_NT;
        private System.Windows.Forms.Label lbTen_NT;
        private System.Windows.Forms.TextBox txtTenDN_NT;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lbTenDN_NT;
        private System.Windows.Forms.Label lbEmail_NT;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.DataGridView dataGridView1;
        private EventHandler lbTenDN_CT_Click;
    }
}
﻿using System;
using System.Windows.Forms;

namespace ThueTro
{
    partial class frmHoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHoaDon));
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbNgayThueTro = new System.Windows.Forms.Label();
            this.txtSoPhong = new System.Windows.Forms.TextBox();
            this.lbSoPhong = new System.Windows.Forms.Label();
            this.txtCCCD_NT = new System.Windows.Forms.TextBox();
            this.lbCCCD_NT = new System.Windows.Forms.Label();
            this.txtMaHoaDon = new System.Windows.Forms.TextBox();
            this.lbMaHoaDon = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.txtTongCong = new System.Windows.Forms.TextBox();
            this.lbTongCong = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(614, 53);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(195, 22);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // lbNgayThueTro
            // 
            this.lbNgayThueTro.AutoSize = true;
            this.lbNgayThueTro.BackColor = System.Drawing.Color.Transparent;
            this.lbNgayThueTro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayThueTro.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbNgayThueTro.Location = new System.Drawing.Point(462, 55);
            this.lbNgayThueTro.Name = "lbNgayThueTro";
            this.lbNgayThueTro.Size = new System.Drawing.Size(151, 20);
            this.lbNgayThueTro.TabIndex = 19;
            this.lbNgayThueTro.Text = "Ngày thanh toán:";
            // 
            // txtSoPhong
            // 
            this.txtSoPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoPhong.Location = new System.Drawing.Point(233, 181);
            this.txtSoPhong.Name = "txtSoPhong";
            this.txtSoPhong.Size = new System.Drawing.Size(199, 27);
            this.txtSoPhong.TabIndex = 2;
            // 
            // lbSoPhong
            // 
            this.lbSoPhong.AutoSize = true;
            this.lbSoPhong.BackColor = System.Drawing.Color.Transparent;
            this.lbSoPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoPhong.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbSoPhong.Location = new System.Drawing.Point(53, 184);
            this.lbSoPhong.Name = "lbSoPhong";
            this.lbSoPhong.Size = new System.Drawing.Size(93, 20);
            this.lbSoPhong.TabIndex = 18;
            this.lbSoPhong.Text = "Số phòng:";
            // 
            // txtCCCD_NT
            // 
            this.txtCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCCCD_NT.Location = new System.Drawing.Point(233, 117);
            this.txtCCCD_NT.Name = "txtCCCD_NT";
            this.txtCCCD_NT.Size = new System.Drawing.Size(199, 27);
            this.txtCCCD_NT.TabIndex = 1;
            // 
            // lbCCCD_NT
            // 
            this.lbCCCD_NT.AutoSize = true;
            this.lbCCCD_NT.BackColor = System.Drawing.Color.Transparent;
            this.lbCCCD_NT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCCCD_NT.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbCCCD_NT.Location = new System.Drawing.Point(53, 120);
            this.lbCCCD_NT.Name = "lbCCCD_NT";
            this.lbCCCD_NT.Size = new System.Drawing.Size(161, 20);
            this.lbCCCD_NT.TabIndex = 17;
            this.lbCCCD_NT.Text = "CCCD người thuê:";
            // 
            // txtMaHoaDon
            // 
            this.txtMaHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHoaDon.Location = new System.Drawing.Point(233, 48);
            this.txtMaHoaDon.Name = "txtMaHoaDon";
            this.txtMaHoaDon.Size = new System.Drawing.Size(199, 27);
            this.txtMaHoaDon.TabIndex = 0;
            // 
            // lbMaHoaDon
            // 
            this.lbMaHoaDon.AutoSize = true;
            this.lbMaHoaDon.BackColor = System.Drawing.Color.Transparent;
            this.lbMaHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaHoaDon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbMaHoaDon.Location = new System.Drawing.Point(53, 55);
            this.lbMaHoaDon.Name = "lbMaHoaDon";
            this.lbMaHoaDon.Size = new System.Drawing.Size(112, 20);
            this.lbMaHoaDon.TabIndex = 16;
            this.lbMaHoaDon.Text = "Mã hóa đơn:";
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSua.Location = new System.Drawing.Point(399, 262);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 41);
            this.btnSua.TabIndex = 6;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnXoa.Location = new System.Drawing.Point(597, 262);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 43);
            this.btnXoa.TabIndex = 7;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLuu.Location = new System.Drawing.Point(190, 263);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 41);
            this.btnLuu.TabIndex = 5;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // txtTongCong
            // 
            this.txtTongCong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongCong.Location = new System.Drawing.Point(610, 120);
            this.txtTongCong.Name = "txtTongCong";
            this.txtTongCong.Size = new System.Drawing.Size(199, 27);
            this.txtTongCong.TabIndex = 4;
            // 
            // lbTongCong
            // 
            this.lbTongCong.AutoSize = true;
            this.lbTongCong.BackColor = System.Drawing.Color.Transparent;
            this.lbTongCong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTongCong.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbTongCong.Location = new System.Drawing.Point(466, 120);
            this.lbTongCong.Name = "lbTongCong";
            this.lbTongCong.Size = new System.Drawing.Size(102, 20);
            this.lbTongCong.TabIndex = 24;
            this.lbTongCong.Text = "Tổng cộng:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 335);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(822, 204);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // frmHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(869, 559);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtTongCong);
            this.Controls.Add(this.lbTongCong);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbNgayThueTro);
            this.Controls.Add(this.txtSoPhong);
            this.Controls.Add(this.lbSoPhong);
            this.Controls.Add(this.txtCCCD_NT);
            this.Controls.Add(this.lbCCCD_NT);
            this.Controls.Add(this.txtMaHoaDon);
            this.Controls.Add(this.lbMaHoaDon);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmHoaDon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hóa đơn";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmHoaDon_FormClosing);
            this.Load += new System.EventHandler(this.frmHoaDon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbNgayThueTro;
        private System.Windows.Forms.TextBox txtSoPhong;
        private System.Windows.Forms.Label lbSoPhong;
        private System.Windows.Forms.TextBox txtCCCD_NT;
        private System.Windows.Forms.Label lbCCCD_NT;
        private System.Windows.Forms.TextBox txtMaHoaDon;
        private System.Windows.Forms.Label lbMaHoaDon;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private EventHandler lbNgayThueTro_Click;
        private System.Windows.Forms.TextBox txtTongCong;
        private System.Windows.Forms.Label lbTongCong;
        private EventHandler label1_Click;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataGridViewCellEventHandler dataGridView1_CellContentClick;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmHoaDonChiTiet : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmHoaDonChiTiet()
        {
            InitializeComponent();
        }

        private void frmHoaDonChiTiet_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void frmHoaDonChiTiet_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from HOADONCHITIET";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "HOADONCHITIET");

            dataGridView1.DataSource = ds.Tables["HOADONCHITIET"];

            con.Close(); //bước 3

            txtThanhTien.Enabled = false;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Bước 1: Mở kết nối cơ sở dữ liệu
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                return;
            }

            // Bước 2: Chuẩn bị dữ liệu
            string sMaHoaDon = txtMaHoaDon.Text.Trim();
            string sMaDV = txtMaDV.Text.Trim();
            string sSoDung = txtSoDung.Text.Trim();
            string retMessage = "";

            // Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sMaHoaDon) || string.IsNullOrEmpty(sMaDV)
                || string.IsNullOrEmpty(sSoDung))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            // Bước 3: Gọi thủ tục lưu hóa đơn chi tiết
            SqlCommand cmd = new SqlCommand("spThemMoiHoaDonChiTiet", con);
            cmd.CommandType = CommandType.StoredProcedure;

            // Thêm tham số cho thủ tục
            cmd.Parameters.AddWithValue("@MaHoaDon", sMaHoaDon);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);
            cmd.Parameters.AddWithValue("@SoDung", sSoDung);

            SqlParameter retParam = new SqlParameter("@ret", SqlDbType.NVarChar, 50);
            retParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(retParam);

            try
            {
                cmd.ExecuteNonQuery();
                retMessage = retParam.Value.ToString(); // Lấy thông báo từ @ret

                if (retMessage == "1")
                {
                    MessageBox.Show("Thêm mới thành công!", "Thông báo");
                }
                else
                {
                    MessageBox.Show("Thêm mới không thành công: " + retMessage, "Thông báo");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm mới: " + ex.Message, "Thông báo");
            }

            // Bước 4: Đóng kết nối
            con.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaHoaDon.Text = dataGridView1.Rows[e.RowIndex].Cells["MaHoaDon"].Value.ToString();
            txtMaDV.Text = dataGridView1.Rows[e.RowIndex].Cells["MaDV"].Value.ToString();
            txtSoDung.Text = dataGridView1.Rows[e.RowIndex].Cells["SoDung"].Value.ToString();
            txtThanhTien.Text = dataGridView1.Rows[e.RowIndex].Cells["ThanhTien"].Value.ToString();

            txtMaHoaDon.Enabled = false;
            txtMaDV.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // Bước 1: Mở kết nối
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                return;
            }

            // Bước 2: Chuẩn bị dữ liệu
            string sMaHoaDon = txtMaHoaDon.Text.Trim();
            string sMaDV = txtMaDV.Text.Trim();
            string sSoDung = txtSoDung.Text.Trim();

            // Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sSoDung))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra số dùng không được nhỏ hơn 0
            if (!int.TryParse(sSoDung, out int soDungValue) || soDungValue < 0)
            {
                MessageBox.Show("Số dùng không hợp lệ!", "Thông báo");
                return;
            }

            //Thực hiện cập nhật
            string updateQuery = @"
                UPDATE HOADONCHITIET
                SET 
                    SoDung = @SoDung
            WHERE MaHoaDon = @MaHoaDon AND MaDV = @MaDV";

            SqlCommand cmd = new SqlCommand(updateQuery, con);
            cmd.Parameters.AddWithValue("@MaHoaDon", sMaHoaDon);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);
            cmd.Parameters.AddWithValue("@SoDung", soDungValue);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sMaHoaDon = txtMaHoaDon.Text;
            string sMaDV = txtMaDV.Text;

            string sQuery = "delete HOADONCHITIET where MaHoaDon = @MaHoaDon and MaDV = @MaDV";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaHoaDon", sMaHoaDon);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmHopDong : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmHopDong()
        {
            InitializeComponent();
        }

        private void frmHopDong_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }


        private void frmHopDong_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from HOPDONG";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "HOPDONG");

            dataGridView1.DataSource = ds.Tables["HOPDONG"];

            con.Close(); //bước 3
            
            txtMaHopDong.Enabled = false;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Bước 1: Mở kết nối cơ sở dữ liệu
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                return;
            }

            // Bước 2: Chuẩn bị dữ liệu
            string sCCCD_NT = txtCCCD_NT.Text.Trim();
            string sSoPhong = txtSoPhong.Text.Trim();
            string sNgayThueTro = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string sNgayHetHan = dateTimePicker2.Value.ToString("yyyy-MM-dd");
            string retMessage = "";


            // Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sCCCD_NT) || string.IsNullOrEmpty(sSoPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            // Bước 3: Gọi thủ tục lưu hợp đồng
            SqlCommand cmd = new SqlCommand("spThemMoiHopDong", con);
            cmd.CommandType = CommandType.StoredProcedure;

            // Thêm tham số cho thủ tục
            cmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);
            cmd.Parameters.AddWithValue("@SoPhong", sSoPhong);
            cmd.Parameters.AddWithValue("@NgayThueTro", sNgayThueTro);
            cmd.Parameters.AddWithValue("@NgayHetHan", sNgayHetHan);

            SqlParameter retParam = new SqlParameter("@ret", SqlDbType.NVarChar, 50);
            retParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(retParam);

            try
            {
                cmd.ExecuteNonQuery();
                retMessage = retParam.Value.ToString(); // Lấy thông báo từ @ret

                if (retMessage == "1")
                {
                    MessageBox.Show("Thêm mới thành công!", "Thông báo");
                }
                else
                {
                    MessageBox.Show("Thêm mới không thành công: " + retMessage, "Thông báo");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm mới: " + ex.Message, "Thông báo");
            }

            // Bước 4: Đóng kết nối
            con.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaHopDong.Text = dataGridView1.Rows[e.RowIndex].Cells["MaHopDong"].Value.ToString();
            txtCCCD_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["CCCD_NT"].Value.ToString();
            txtSoPhong.Text = dataGridView1.Rows[e.RowIndex].Cells["SoPhong"].Value.ToString();
            dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["NgayThueTro"].Value);
            dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells["NgayHetHan"].Value);
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            // Bước 1: Mở kết nối
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB: " + ex.Message, "Thông báo");
                return;
            }

            // Bước 2: Chuẩn bị dữ liệu
            string sMaHopDong = txtMaHopDong.Text.Trim();
            string sCCCD_NT = txtCCCD_NT.Text.Trim();
            string sSoPhong = txtSoPhong.Text.Trim();
            string sNgayThueTro = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string sNgayHetHan = dateTimePicker2.Value.ToString("yyyy-MM-dd");

            // Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sCCCD_NT) || string.IsNullOrEmpty(sSoPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra CCCD có tồn tại không
            string checkCCCDQuery = "SELECT COUNT(*) FROM NGUOITHUETRO WHERE CCCD_NT = @CCCD_NT";
            SqlCommand checkCCCDCmd = new SqlCommand(checkCCCDQuery, con);
            checkCCCDCmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);

            int cccdExists = (int)checkCCCDCmd.ExecuteScalar();
            if (cccdExists == 0)
            {
                MessageBox.Show("CCCD không tồn tại trong bảng NGUOITHUETRO!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra số phòng có tồn tại không
            string checkPhongQuery = "SELECT COUNT(*) FROM PHONG WHERE SoPhong = @SoPhong";
            SqlCommand checkPhongCmd = new SqlCommand(checkPhongQuery, con);
            checkPhongCmd.Parameters.AddWithValue("@SoPhong", sSoPhong);

            int phongExists = (int)checkPhongCmd.ExecuteScalar();
            if (phongExists == 0)
            {
                MessageBox.Show("Số phòng không tồn tại trong bảng PHONG!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra ngày thuê và ngày hết hạn
            DateTime ngayThueTro = DateTime.Parse(sNgayThueTro);
            DateTime ngayHetHan = DateTime.Parse(sNgayHetHan);
            if (ngayThueTro > DateTime.Now)
            {
                MessageBox.Show("Ngày thuê trọ không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            if ((ngayHetHan - ngayThueTro).TotalDays < 90)
            {
                MessageBox.Show("Ngày hết hạn không hợp lệ (thời hạn hợp đồng tối thiểu 3 tháng)!", "Thông báo");
                con.Close();
                return;
            }

            // Thực hiện cập nhật
            string updateQuery = @"
                UPDATE HOPDONG
                SET 
                    CCCD_NT = @CCCD_NT,
                    SoPhong = @SoPhong,
                    NgayThueTro = @NgayThueTro,
                    NgayHetHan = @NgayHetHan
                WHERE MaHopDong = @MaHopDong";

            SqlCommand cmd = new SqlCommand(updateQuery, con);
            cmd.Parameters.AddWithValue("@MaHopDong", sMaHopDong);
            cmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);
            cmd.Parameters.AddWithValue("@SoPhong", sSoPhong);
            cmd.Parameters.AddWithValue("@NgayThueTro", sNgayThueTro);
            cmd.Parameters.AddWithValue("@NgayHetHan", sNgayHetHan);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sMaHopDong = txtMaHopDong.Text;

            string sQuery = "delete HOPDONG where MaHopDong = @MaHopDong";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaHopDong", sMaHopDong);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmDichVu : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmDichVu()
        {
            InitializeComponent();
        }

        private void frmDichVu_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Hiển thị hộp thoại xác nhận khi người dùng muốn đóng form
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void frmDichVu_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from DICHVU";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "DICHVU");

            dataGridView1.DataSource = ds.Tables["DICHVU"];

            con.Close(); //bước 3
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sMaDV = txtMaDV.Text.Trim();
            string sTenDV = txtTenDV.Text.Trim();
            string sDonVi = txtDonVi.Text.Trim();
            string sDonGia = txtDonGia.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sMaDV) || string.IsNullOrEmpty(sTenDV) ||
                string.IsNullOrEmpty(sDonVi) || string.IsNullOrEmpty(sDonGia))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sMaDV.Length != 4)
            {
                MessageBox.Show("Mã dịch vụ phải đúng 4 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra đơn giá không được nhỏ hơn 0
            if (!decimal.TryParse(sDonGia, out decimal donGia) || donGia <= 0)
            {
                MessageBox.Show("Đơn giá không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra trùng lặp
            // Kiểm tra SoPhong 
            string checkMaDVQuery = "SELECT COUNT(*) FROM DICHVU WHERE MaDV = @MaDV";
            SqlCommand checkMaDVCmd = new SqlCommand(checkMaDVQuery, con);
            checkMaDVCmd.Parameters.AddWithValue("@MaDV", sMaDV);

            int madvExists = (int)checkMaDVCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (madvExists > 0)
            {
                MessageBox.Show("Mã dịch vụ đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "insert into DICHVU values (@MaDV, @TenDV, @DonVi, @DonGia)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);
            cmd.Parameters.AddWithValue("@TenDV", sTenDV);
            cmd.Parameters.AddWithValue("@DonVi", sDonVi);
            cmd.Parameters.AddWithValue("@DonGia", sDonGia);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình thêm mới!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtMaDV.Text = dataGridView1.Rows[e.RowIndex].Cells["MaDV"].Value.ToString();
            txtTenDV.Text = dataGridView1.Rows[e.RowIndex].Cells["TenDV"].Value.ToString();
            txtDonVi.Text = dataGridView1.Rows[e.RowIndex].Cells["DonVi"].Value.ToString();
            txtDonGia.Text = dataGridView1.Rows[e.RowIndex].Cells["DonGia"].Value.ToString();

            txtMaDV.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sMaDV = txtMaDV.Text.Trim();
            string sTenDV = txtTenDV.Text.Trim();
            string sDonVi = txtDonVi.Text.Trim();
            string sDonGia = txtDonGia.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sTenDV) ||
                string.IsNullOrEmpty(sDonVi) || string.IsNullOrEmpty(sDonGia))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            //Kiểm tra đơn giá không được nhỏ hơn 0
            if (!decimal.TryParse(sDonGia, out decimal donGia) || donGia <= 0)
            {
                MessageBox.Show("Đơn giá không hợp lệ!", "Thông báo");
                con.Close();
                return;
            }

            //Thực hiện cập nhật
            string sQuery = "update DICHVU set TenDV = @TenDV," +
                "DonVi = @DonVi, DonGia = @DonGia where MaDV = @MaDV";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);
            cmd.Parameters.AddWithValue("@TenDV", sTenDV);
            cmd.Parameters.AddWithValue("@DonVi", sDonVi);
            cmd.Parameters.AddWithValue("@DonGia", sDonGia);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình cập nhật!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sMaDV = txtMaDV.Text;

            string sQuery = "delete DICHVU where MaDV = @MaDV";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaDV", sMaDV);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}

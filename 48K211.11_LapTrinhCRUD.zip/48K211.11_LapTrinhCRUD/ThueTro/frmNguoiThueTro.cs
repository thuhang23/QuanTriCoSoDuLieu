﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; //Bước 0

namespace ThueTro
{
    public partial class frmNguoiThueTro : Form
    {
        string sCon = "Data Source=LAPTOP-BOA7V1H0\\MSSQLSERVER03;Initial Catalog=ThueTro;Integrated Security=True;";
        public frmNguoiThueTro()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            string sQuery = "select * from NGUOITHUETRO";
            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "NGUOITHUETRO");

            dataGridView1.DataSource = ds.Tables["NGUOITHUETRO"];

            con.Close(); //bước 3
        }

        private void frmNguoiThueTro_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Nếu người dùng chọn No, ngừng sự kiện đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true; // Ngừng đóng form
            }
            else
            {
                // Nếu người dùng chọn Yes, thực hiện lưu hoặc các hành động khác trước khi đóng
                // Lưu dữ liệu tại đây nếu cần
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sCCCD_NT = txtCCCD_NT.Text.Trim();
            string sTen_NT = txtTen_NT.Text.Trim();
            string sSDT_NT = txtSDT_NT.Text.Trim();
            string sDiaChi_NT = txtDiaChi_NT.Text.Trim();
            string sEmail = txtEmail.Text.Trim();
            string sTenDN_NT = txtTenDN_NT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sCCCD_NT) || string.IsNullOrEmpty(sTen_NT) ||
                string.IsNullOrEmpty(sSDT_NT) || string.IsNullOrEmpty(sDiaChi_NT) ||
                string.IsNullOrEmpty(sTenDN_NT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sCCCD_NT.Length != 12)
            {
                MessageBox.Show("CCCD phải đúng 12 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            if (sSDT_NT.Length != 10)
            {
                MessageBox.Show("Số điện thoại phải đúng 10 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra trùng lặp
            // Kiểm tra CCCD_CT
            string checkCCCDQuery = "SELECT COUNT(*) FROM NGUOITHUETRO WHERE CCCD_NT = @CCCD_NT";
            SqlCommand checkCCCDCmd = new SqlCommand(checkCCCDQuery, con);
            checkCCCDCmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);

            int cccdExists = (int)checkCCCDCmd.ExecuteScalar(); // Lấy số lượng bản ghi trùng
            if (cccdExists > 0)
            {
                MessageBox.Show("CCCD đã tồn tại! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra xem tên đăng nhập có tồn tại trong bảng TAIKHOAN không
            string checkTenDNQuery = "SELECT COUNT(*) FROM TAIKHOAN_NT WHERE TenDN_NT = @TenDN_NT";
            SqlCommand checkTenDNCmd = new SqlCommand(checkTenDNQuery, con);
            checkTenDNCmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            int tenDNExists = (int)checkTenDNCmd.ExecuteScalar();
            if (tenDNExists == 0) // Tên đăng nhập chưa tồn tại
            {
                MessageBox.Show("Tên đăng nhập không tồn tại trong bảng TAIKHOAN_NT! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra tên đăng nhập trong bảng NGUOITHUETRO
            string checkTenDNInNGUOITHUETROQuery = "SELECT COUNT(*) FROM NGUOITHUETRO WHERE TenDN_NT = @TenDN_NT";
            SqlCommand checkTenDNInNGUOITHUETROCmd = new SqlCommand(checkTenDNInNGUOITHUETROQuery, con);
            checkTenDNInNGUOITHUETROCmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            int tenDNInNGUOITHUETROExists = (int)checkTenDNInNGUOITHUETROCmd.ExecuteScalar();
            if (tenDNInNGUOITHUETROExists > 0)
            {
                MessageBox.Show("Tên đăng nhập đã bị trùng! Vui lòng chọn tên khác.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "insert into NGUOITHUETRO values (@CCCD_NT, @Ten_NT, @SDT_NT, @DiaChi_NT, @Email, @TenDN_NT)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);
            cmd.Parameters.AddWithValue("@Ten_NT", sTen_NT);
            cmd.Parameters.AddWithValue("@SDT_NT", sSDT_NT);
            cmd.Parameters.AddWithValue("@DiaChi_NT", sDiaChi_NT);
            cmd.Parameters.AddWithValue("@Email", sEmail);
            cmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình thêm mới!", "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCCCD_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["CCCD_NT"].Value.ToString();
            txtTen_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["Ten_NT"].Value.ToString();
            txtSDT_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["SDT_NT"].Value.ToString();
            txtDiaChi_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["DiaChi_NT"].Value.ToString();
            txtEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            txtTenDN_NT.Text = dataGridView1.Rows[e.RowIndex].Cells["TenDN_NT"].Value.ToString();

            txtCCCD_NT.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {

            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
                return;
            }

            //Bước 2
            //chuan bi du lieu
            //gan du lieu vao bien
            string sCCCD_NT = txtCCCD_NT.Text.Trim();
            string sTen_NT = txtTen_NT.Text.Trim();
            string sSDT_NT = txtSDT_NT.Text.Trim();
            string sDiaChi_NT = txtDiaChi_NT.Text.Trim();
            string sEmail = txtEmail.Text.Trim();
            string sTenDN_NT = txtTenDN_NT.Text.Trim();

            //Kiểm tra tính hợp lệ của dữ liệu
            if (string.IsNullOrEmpty(sTen_NT) ||
                string.IsNullOrEmpty(sSDT_NT) || string.IsNullOrEmpty(sDiaChi_NT) ||
                string.IsNullOrEmpty(sTenDN_NT))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                con.Close();
                return;
            }

            if (sSDT_NT.Length != 10)
            {
                MessageBox.Show("Số điện thoại phải đúng 10 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra xem tên đăng nhập có tồn tại trong bảng TAIKHOAN không
            string checkTenDNQuery = "SELECT COUNT(*) FROM TAIKHOAN_NT WHERE TenDN_NT = @TenDN_NT";
            SqlCommand checkTenDNCmd = new SqlCommand(checkTenDNQuery, con);
            checkTenDNCmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            int tenDNExists = (int)checkTenDNCmd.ExecuteScalar();
            if (tenDNExists == 0) // Tên đăng nhập chưa tồn tại
            {
                MessageBox.Show("Tên đăng nhập không tồn tại trong bảng TAIKHOAN_NT! Vui lòng kiểm tra lại.", "Thông báo");
                con.Close();
                return;
            }

            // Kiểm tra tên đăng nhập trong bảng NGUOITHUETRO
            // Nếu tên đăng nhập mới trùng với tên đăng nhập cũ thì không cần thông báo
            string checkTenDNInNGUOITHUETROQuery = "SELECT COUNT(*) FROM NGUOITHUETRO WHERE TenDN_NT = @TenDN_NT AND CCCD_NT != @CCCD_NT";
            SqlCommand checkTenDNInNGUOITHUETROCmd = new SqlCommand(checkTenDNInNGUOITHUETROQuery, con);
            checkTenDNInNGUOITHUETROCmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);
            checkTenDNInNGUOITHUETROCmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);

            int tenDNInNGUOITHUETROExists = (int)checkTenDNInNGUOITHUETROCmd.ExecuteScalar();
            if (tenDNInNGUOITHUETROExists > 0)
            {
                MessageBox.Show("Tên đăng nhập đã bị trùng! Vui lòng chọn tên khác.", "Thông báo");
                con.Close();
                return;
            }

            // Chuẩn bị câu lệnh SQL
            string sQuery = "UPDATE NGUOITHUETRO SET Ten_NT = @Ten_NT, SDT_NT = @SDT_NT, " +
                    "DiaChi_NT = @DiaChi_NT, Email = @Email, TenDN_NT = @TenDN_NT " +
                    "WHERE CCCD_NT = @CCCD_NT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);
            cmd.Parameters.AddWithValue("@Ten_NT", sTen_NT);
            cmd.Parameters.AddWithValue("@SDT_NT", sSDT_NT);
            cmd.Parameters.AddWithValue("@DiaChi_NT", sDiaChi_NT);
            cmd.Parameters.AddWithValue("@Email", sEmail);
            cmd.Parameters.AddWithValue("@TenDN_NT", sTenDN_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật! " , "Thông báo");
            }

            con.Close(); //Bước 3
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối DB", "Thông báo");
            }

            //Bước 2
            //lấy giá trị
            string sCCCD_NT = txtCCCD_NT.Text;

            string sQuery = "delete NGUOITHUETRO where CCCD_NT = @CCCD_NT";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@CCCD_NT", sCCCD_NT);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Xoá thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong qua trình xoá!", "Thông báo");
            }

            con.Close(); //Bước 3
        }
    }
}
